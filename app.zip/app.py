from flask import Flask, jsonify, request
from models import User, Company, RawMaterial
from mongoengine import connect
from flask_cors import CORS
import json
import hashlib

app = Flask(__name__)
with open('config.json') as config_file:
   config = json.load(config_file)
# connect(host="mongodb+srv://{username}:{password}@{dbName}/?retryWrites=true&w=majority".format(username=config['database_username'],password=config['database_password'],dbName=config['database_server']),db="ims")
connect(host='mongodb://127.0.0.1:27017/stock-and-inventory')
@app.route('/')
def index():
   return jsonify({"status":"working"})


# User routes 
 
@app.route('/register', methods=['POST'])
def register():
   if request.method == 'POST' and request.headers.get('source-name') == 'streamlining-inventory-management':
      data = request.get_json(force=True)
      existing_users_by_email = User.objects(email=data['email'])
      existing_users_by_username = User.objects(username=data['username'])
      if existing_users_by_email or existing_users_by_username:
         return jsonify({"result":"User already exists"}),409
      user = User(username=data['username'],email=data['email'], password=hashlib.md5(data['password'].encode()).hexdigest())
      result = user.save()
      if result:
         return jsonify({"status":"success"}), 201
   else:
      return jsonify({'res':'Request cannot be processed'}),406 

@app.route('/login', methods=['POST'])
def login():
   if request.method == 'POST' and request.headers.get('source-name') == 'streamlining-inventory-management':
      data = request.get_json(force=True)
      user = User.objects(username=data['username'],password=hashlib.md5(data['password'].encode()).hexdigest())       
      if user:
         return jsonify({'username':user[0]['username'],'email': user[0]['email']}),200 
      else:
         return {"result":"no user found"},404 
   else:
      return jsonify({'res':'Request cannot be processed'}),406    

@app.route('/delete-user', methods=['POST'])
def delete_user():
   if request.method == 'POST' and request.headers.get('source-name') == 'streamlining-inventory-management':
      data = request.get_json(force=True)
      if data['username']:
         user = User.objects(username=data['username'])
         user[0].delete()
         return jsonify({"status":"sucesss"}),202
      elif data['email']:
         user = User.objects(email=data['email'])  
         user[0].delete()
         return jsonify({"status":"sucesss"}),202
      return jsonify({"status":"not found"}),404
   
# Company routes
@app.route('/company')  
def get_company():
   all_companies = Company.objects
   companies = []
   for company in all_companies:
      companies.append(dict({"name": company.name
                             })) 
   return jsonify({"companies": companies})

@app.route('/company/<name>')  
def get_specific_company(name):
   company = (Company.objects(name=name))
   company_name = {
      "name" : company[0].name
   }
   return jsonify(company_name)

@app.route('/add-company',methods=['POST'])
def add_company():
   if request.method == 'POST' and request.headers.get('source-name') == 'streamlining-inventory-management':
      data = request.get_json(force=True)
      company_by_name = Company.objects(name=data['name'])
      company_by_gst = Company.objects(gst_no=data['gst_no'])
      if company_by_gst and company_by_name:
         return jsonify({"result":"Company already exists"}),409
      else:
         result = Company(
            name=data['name'],
            address= data['address'],
            city= data['city'],
            pincode= data['pincode'],
            state= data['state'],
            gst_no= data['gst_no'],
            company_in_sez= data['company_in_sez'],
            company_type= data['company_type'],
            supplier_type= data['supplier_type'],
            distance_from_andheri= data['distance_from_andheri'],
            distance_from_vasai= data['distance_from_vasai']
         ).save()
      return jsonify({"status":"success"}), 201

@app.route('/removeCompany', methods=['POST'])
def remove_company():
   if request.method == 'POST' and request.headers.get('source-name') == 'streamlining-inventory-management':
      data = request.get_json(force=True)
      if data['name']:
         company = Company.objects(name=data['name'])
         company[0].delete()
         return jsonify({"status":"sucesss"}),202
      elif data['gst_no']:
         company = Company.objects(gst_no=data['gst_no'])  
         company[0].delete()
         return jsonify({"status":"sucesss"}),202
      else:
         return jsonify({"status":"not found"}),404
         


# Raw material routes
@app.route('/rawMaterial')
def get_materials():
   all_raw_materials = RawMaterial.objects
   raw_materials = []
   for raw_material in all_raw_materials:
      raw_materials.append(dict({"name": raw_material.item_name
                             })) 
   return jsonify({"raw_materials": raw_materials})

@app.route('/rawMaterial/<name>')  
def get_specific_material(name):
   raw_material = (RawMaterial.objects(item_name=name))
   raw_material_name = {
      "name" : raw_material[0].item_name
   }
   return jsonify(raw_material_name)


@app.route('/addMaterial', methods=['POST'])
def add_material():
   if request.method == 'POST' and request.headers.get('source-name') == 'streamlining-inventory-management':
      data = request.get_json(force=True)
      raw_material_by_name = RawMaterial.objects(item_name=data['item_name'])
      if raw_material_by_name:
         return jsonify({"result":"Company already exists"}),409
      else:
         RawMaterial(
            item_name=data['item_name'],
            rod_diameter = data['rod_diameter'],
            line_weight = data['line_weight'],
            unit_price = data['unit_price'],
            quantity = data['quantity']
            ).save()
      return jsonify({"status":"success"}), 201

@app.route('/removeMaterial', methods=['POST'])
def remove_material():
    if request.method == 'POST' and request.headers.get('source-name') == 'streamlining-inventory-management':
      data = request.get_json(force=True)
      if data['item_name']:
         user = RawMaterial.objects(item_name=data['item_name'])
         user[0].delete()
         return jsonify({"status":"sucesss"}),202
      else:
         return jsonify({"status":"not found"}),404

# Bill generation route



